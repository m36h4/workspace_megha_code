# Dataset Analyzer — Deep Recursive Dataset Audit Tool

A single reusable Python script (`dataset_analyzer.py`, ~1,165 lines) that recursively
audits an object-detection dataset — folder by folder, subfolder by subfolder, class by
class — and produces a full client-ready report bundle: Excel, CSVs, PNG charts, and an
HTML report.

## Install

```bash
pip install -r requirements.txt
```

`scikit-image` and `tqdm` are optional — the script degrades gracefully (built-in entropy
calc / plain progress printing) if they aren't installed, so it will still run on a bare
client machine. `opencv-python`, `numpy`, `pandas`, `Pillow`, `matplotlib`, `openpyxl` are
required.

## Run

```bash
python dataset_analyzer.py --root /path/to/Dataset --out ./analysis
```

Your dataset can look like:

```
Dataset/
├── basic_train_caseA/
│     basketball/  img001.jpg  img001.json  ...
│     rugby/       ...
│     soccer/      ...
│     volleyball/  ...
├── basic_eval_caseA/
├── cc0_train_caseB/     (YOLO .txt labels)
└── other_any_caseA/     (single COCO annotations.json)
```

Every **top-level folder** is scanned independently, and the script **auto-detects which
annotation format that folder uses**:

| Format | How it's detected |
|---|---|
| **COCO** | A `*.json` anywhere in the folder containing `images` / `annotations` / `categories` keys |
| **YOLO** | Per-image `*.txt` files (`class cx cy w h`, normalized); reads `classes.txt` / `obj.names` if present |
| **Generic JSON** | Per-image `*.json` files — flexibly parses `bbox: [x,y,w,h]`, `xmin/ymin/xmax/ymax`, `x1/y1/x2/y2`, LabelMe-style `points`, etc., and `class`/`label`/`category`/`name` for the class field |

No annotations found in a folder → it's still fully audited for image quality, resolution,
duplicates, and naming issues, with an "images without labels" flag on every image.

### Useful flags

```
--sample N          only process N images per top folder (fast preview run)
--hash-threshold N  hamming-distance cutoff for near-duplicate detection (default 5)
--no-plots          skip PNG chart generation
--no-html           skip the HTML report
```

## What it computes

- **Structure**: images, labels, missing images/labels, corrupt images, invalid JSON
- **Per folder / subfolder / class**: image count, object count, avg objects/image, mean
  resolution, mean brightness/contrast/blur, % blurry, % over/under-exposed
- **Image properties**: resolution distribution, width/height, aspect ratio, orientation
  (landscape/portrait/square)
- **Pixel stats**: mean/std R,G,B, brightness, contrast, saturation, entropy
- **Annotation stats**: objects/image, bbox width/height/area/aspect ratio
- **BBox analysis**: relative size (% of image), size bucket (Tiny/Small/Medium/Large),
  center-point heatmap, edge-touching & truncated-box flags
- **Quality**: duplicate & near-duplicate images (custom dHash + pHash, no external
  dependency needed), blur bucket, exposure bucket
- **Class distribution**: images/class, objects/class, imbalance ratio vs. the largest class
- **File naming**: non-ASCII filenames, same-name collisions within/across folders,
  risky/unsupported extensions
- **Label validation**: negative coordinates, zero-size boxes, boxes exceeding image
  bounds, empty label files, malformed JSON
- **Cross-folder duplicate detection**
- **COCO-readiness checklist** (missing/invalid/empty labels, duplicate images, corrupt
  images — pass/review status per check)

## Output (`./analysis/`)

```
analysis/
    dataset_summary.xlsx       <- one workbook, every table on its own sheet
    dataset_summary.csv
    folder_statistics.csv
    image_statistics.csv       <- one row per image, every metric above
    bbox_statistics.csv        <- one row per bounding box
    duplicate_images.csv
    blurry_images.csv
    invalid_annotations.csv
    plots/
        resolution.png  bbox_area.png  bbox_scatter.png  object_count.png
        brightness.png  contrast.png   blur.png           saturation.png
        entropy.png     rgb_histogram.png  heatmap.png    class_distribution.png
        folder_comparison.png  size_buckets.png
    report.html                 <- open this in a browser to hand to the client
```

## Notes on scale

- Near-duplicate detection is exhaustive (pairwise hamming distance) up to ~6,000 unique
  image hashes per run; beyond that it still runs exact-duplicate detection but skips the
  full pairwise near-duplicate pass and prints a note. For a very large client dataset,
  run it once per top-level folder (`--root Dataset/basic_train_caseA`) to keep this
  bounded, or ask me to add LSH/bucketed hashing for larger scale.
- Everything runs single-process. If a folder has hundreds of thousands of images, expect
  a genuinely long run — multiprocessing over images is a natural extension point
  (`_process_one_image` is already isolated per-image) if you need it faster.
- The generic-JSON bbox parser is heuristic (auto-detects `xywh` vs `xyxy` vs normalized).
  If your actual client JSON has a format it doesn't handle, send me one sample label file
  and I'll wire in an exact reader in a couple of lines — the parsing layer is fully
  isolated (`parse_generic_json_label`) so nothing else in the script needs to change.

## Tested against

A synthetic 3-format dataset (generic-JSON with class subfolders, YOLO, and COCO) mixing
in: a missing label, a malformed JSON label, an exact-duplicate image, and a non-ASCII
filename — all were correctly detected end-to-end before this was handed to you.
