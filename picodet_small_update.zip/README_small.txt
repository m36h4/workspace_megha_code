PicoDet-ESNet, fine strides only (8 and 16)   --   picodet_small_update.zip

Extract everything into your PicoDet scripts folder (overwrite when asked).

GFLOPs at 320x480 (LeakyReLU, sigmoid gate):
  current headslim (strides 8/16/32/64) 0.931   |  this, neck 96: 0.740 (-20%)  |  this, neck 64: 0.559 (-40%)
  (ONNX all-op count incl. box decode: 0.985 -> 0.789 for neck 96)

TRAIN -- directly at 320x480 now (largest stride is 16, so the 64 rule no longer applies):
  python picodet_esnet_small.py --data dataset.yaml --weights runs/train/picodet_exp/weights/best.pt --device 0
  add --neck 64 for the 0.56 GFLOPs version.
  --weights = your current headslim best.pt (or LibrePICODETs.pt): every kept layer is warm-started.
  lr: default 0.1 is for batch 64; smaller batch -> lr0 = 0.1 x batch / 64.

GFLOPs of this model:  python picodet_esnet_small.py --profile-only --neck 96
  (profile_picodet.py / diagnose_picodet.py refuse this checkpoint on purpose -- they would build the wrong model)

EXPORT + CHECK:
  python export_onnx.py --weights runs/train/<run>/weights/best.pt --arch esnet_small --imgsz 320 480 --out picodet_small.onnx
  must print "OK: ONNX output matches PyTorch"
  python check_client_compat.py --onnx picodet_small.onnx        -> expect 0 FAIL (the concat WATCH is gone too)

EVAL:  same as before, e.g.  python picodet_eval_onnx.py --data dataset_eval.yaml --onnx picodet_small.onnx --imgsz 320 480 ...

Trade-off to check: big balls (64px+ on the canvas) lose the coarse levels that served them.
  python ball_size_report.py --data dataset_eval.yaml --onnx <current model .onnx>   -> look at the 64+px row
