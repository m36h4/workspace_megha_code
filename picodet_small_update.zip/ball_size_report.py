"""Answers "can we drop the stride-8 level?" from YOUR data.

1. Ball size distribution, measured in pixels on the 480x320 letterboxed canvas the model
   actually sees (sqrt of box area).
2. Optional (--onnx): your current model's recall per size bin, so you can see how much of
   today's recall comes from balls too small for a stride-16 grid.

Rule of thumb: the finest level's stride is roughly the smallest object it handles well.
Strides 8/16/32/64 -> ~8 px and up. Dropping stride 8 -> ~16 px and up.

Usage:
    python ball_size_report.py --data dataset_eval.yaml
    python ball_size_report.py --data dataset_eval.yaml --onnx ONNX/picodet_leakyrelu.onnx --preproc picodet
"""
import argparse

import numpy as np

from picodet_eval import greedy_match, load_ground_truth

BINS = [(0, 8), (8, 16), (16, 24), (24, 32), (32, 64), (64, 1e9)]


def canvas_sizes(images, gts, canvas_hw):
    import cv2
    H, W = canvas_hw
    out = {}
    for img_id, path in images.items():
        g = gts[img_id]
        if not len(g):
            out[img_id] = np.zeros(0)
            continue
        h, w = cv2.imread(path).shape[:2]
        r = min(H / h, W / w)
        out[img_id] = np.sqrt((g[:, 2] - g[:, 0]) * (g[:, 3] - g[:, 1])) * r
    return out


def label(lo, hi):
    return f"{lo:>3.0f}-{hi:<3.0f}px" if hi < 1e9 else f"{lo:>3.0f}+    px"


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--data", required=True)
    p.add_argument("--split", default="val")
    p.add_argument("--imgsz", type=int, nargs=2, default=[320, 480], metavar=("H", "W"))
    p.add_argument("--onnx", default=None)
    p.add_argument("--preproc", default="picodet", help="picodet | nanodetplus (see picodet_eval_onnx.py)")
    p.add_argument("--conf", type=float, default=0.25)
    p.add_argument("--iou", type=float, default=0.5)
    args = p.parse_args()

    images, gts, _ = load_ground_truth(args.data, args.split)
    sizes = canvas_sizes(images, gts, tuple(args.imgsz))
    all_s = np.concatenate(list(sizes.values())) if sizes else np.zeros(0)
    n = len(all_s)
    print(f"{args.split}: {len(images)} images, {n} balls | size on the {args.imgsz[1]}x{args.imgsz[0]} canvas (sqrt area)")
    print(f"  median {np.median(all_s):.1f}px | 10th pct {np.percentile(all_s, 10):.1f}px | smallest {all_s.min():.1f}px\n")

    per_bin_recall = None
    if args.onnx:
        from picodet_eval_onnx import run_onnx_inference
        preds = run_onnx_inference(args.onnx, images, tuple(args.imgsz), 0.001, 0.45, 300, preproc=args.preproc)
        hit, tot = np.zeros(len(BINS)), np.zeros(len(BINS))
        for img_id, g in gts.items():
            if not len(g):
                continue
            d = preds[img_id]
            d = d[d[:, 4] >= args.conf]
            d = d[np.argsort(-d[:, 4])]
            _, matched = greedy_match(d, g, args.iou)
            for s, m in zip(sizes[img_id], matched):
                b = next(i for i, (lo, hi) in enumerate(BINS) if lo <= s < hi)
                tot[b] += 1
                hit[b] += m
        per_bin_recall = (hit, tot)

    print(f"  {'ball size':<12}{'count':>7}{'share':>8}" + (f"{'recall now':>12}" if per_bin_recall else ""))
    for i, (lo, hi) in enumerate(BINS):
        c = int(((all_s >= lo) & (all_s < hi)).sum())
        row = f"  {label(lo, hi):<12}{c:>7}{100 * c / max(n, 1):>7.1f}%"
        if per_bin_recall:
            hit, tot = per_bin_recall
            row += f"{(hit[i] / tot[i] if tot[i] else float('nan')):>12.3f}"
        print(row)
    small = (all_s < 16).sum()
    print(f"\n  balls under 16px: {small} of {n} ({100 * small / max(n, 1):.1f}%)  "
          f"<- these are the ones that get weaker if stride 8 is dropped")
    if per_bin_recall:
        hit, tot = per_bin_recall
        lost_max = hit[:2].sum()
        print(f"  recall today:  {hit.sum() / tot.sum():.3f} overall | {lost_max:.0f} of today's {hit.sum():.0f} hits are under 16px "
              f"(worst case, recall would fall to {(hit.sum() - lost_max) / tot.sum():.3f} if ALL of those were lost)")


if __name__ == "__main__":
    main()
