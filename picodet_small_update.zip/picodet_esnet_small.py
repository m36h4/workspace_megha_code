"""PicoDet-ESNet that keeps only the FINE strides (8 and 16) -- the levels that see small
balls -- and drops strides 32/64 together with the backbone stage that only fed them.

Measured at 320x480 (LeakyReLU, sigmoid gate, slimmed head):
    current headslim, strides 8/16/32/64 : 0.931 GFLOPs, 0.91M params
    this, strides 8/16, neck 96          : 0.740 GFLOPs (-20%), 0.36M params
    this, strides 8/16, neck 64          : 0.559 GFLOPs (-40%), 0.29M params

Because the largest stride is now 16, this model trains directly at 320x480 (the client's
size) -- the 64-divisibility rule only existed because of the stride-64 level.

Warm start (recommended): --weights <your headslim best.pt> or LibrePICODETs.pt.
Every kept layer has the same shape and name as before, so its trained weights carry over.
The one neck block whose position changes (the P4->P3 merge) is remapped explicitly.

Usage:
    python picodet_esnet_small.py --data dataset.yaml --weights runs/train/picodet_exp/weights/best.pt --device 0
    python picodet_esnet_small.py --data dataset.yaml --weights <ckpt> --neck 64 --device 0
    python picodet_esnet_small.py --profile-only --neck 64            # just print GFLOPs

Reload a trained checkpoint (neck width is read from the file):
    from picodet_esnet_small import load_small;  model = load_small("runs/train/<run>/weights/best.pt")
"""
import argparse

import torch
import torch.nn as nn
import libreyolo.training.trainer as _trainer
from libreyolo.models.picodet.model import LibrePICODET
from libreyolo.models.picodet.nn import CSPPAN, ESNet, PicoHead, SIZE_SPEC, LibrePICODETModel

import picodet_letterbox  # noqa: F401  -- letterbox + Paddle-style aug, same as the other scripts
from picodet_activation import ACTS, GATES, set_activation
from picodet_esnet_headslim import _act_candidates, _force_activation, _force_gate

STRIDES = (8, 16)
STACKED_CONVS = 1
# LibreYOLO checks imgsz against a fixed per-family "maximum stride" (64 for PicoDet). This
# model's real maximum stride is 16, so 320x480 is valid; only affects this process.
_trainer.RECTANGULAR_TRAINING_FAMILIES["picodet"] = 16


class ESNetFine(nn.Module):
    """ESNet that stops after the stride-16 stage. Module names match ESNet
    (conv1, blocks.N), so existing ESNet weights load by name."""

    def __init__(self, model_size="s"):
        super().__init__()
        e = ESNet(model_size)
        self.idx = tuple(e.OUT_INDICES[:2])                      # (2, 9) -> strides 8, 16
        self.conv1, self.max_pool = e.conv1, e.max_pool
        self.blocks = nn.ModuleList(list(e.blocks)[: self.idx[-1] + 1])
        self.out_channels = tuple(e.out_channels[:2])

    def forward(self, x):
        x = self.max_pool(self.conv1(x))
        outs = []
        for i, b in enumerate(self.blocks):
            x = b(x)
            if i in self.idx:
                outs.append(x)
        return outs


class PicoDetSmallModel(LibrePICODETModel):
    def __init__(self, size="s", nb_classes=80, neck_ch=96):
        super().__init__(size=size, nb_classes=nb_classes)
        self.backbone = ESNetFine(SIZE_SPEC[size]["backbone"])
        err = None
        for act in _act_candidates():
            try:
                self.neck = CSPPAN(in_channels=self.backbone.out_channels, out_channels=neck_ch, kernel_size=5,
                                   num_features=3, expansion=1.0, num_csp_blocks=1, use_depthwise=True, act=act)
                self.head = PicoHead(in_channels=neck_ch, num_classes=nb_classes, feat_channels=neck_ch,
                                     stacked_convs=STACKED_CONVS, kernel_size=5, reg_max=7, strides=STRIDES,
                                     share_cls_reg=True, use_depthwise=True, act=act)
                break
            except ValueError as e:
                if "activation" not in str(e).lower():
                    raise
                err = e
        else:
            raise RuntimeError("no activation name accepted by the installed CSPPAN/PicoHead") from err
        for part in (self.backbone, self.neck):
            for m in part.modules():
                if isinstance(m, nn.Conv2d):
                    nn.init.kaiming_normal_(m.weight, mode="fan_out", nonlinearity="relu")
                    if m.bias is not None:
                        nn.init.zeros_(m.bias)
                elif isinstance(m, nn.BatchNorm2d):
                    nn.init.ones_(m.weight)
                    nn.init.zeros_(m.bias)
        for part in (self.backbone, self.neck, self.head):
            _force_activation(part)
        _force_gate(self.backbone)


class PicoDetSmallStride(LibrePICODET):
    """Constructor kwargs become attributes before _init_model(): PicoDetSmallStride(size="s", neck_ch=96)."""

    neck_ch = 96

    def _init_model(self):
        return PicoDetSmallModel(size=self.size, nb_classes=self.nb_classes, neck_ch=self.neck_ch)

    def _get_available_layers(self):
        b = self.model.backbone
        return {"backbone_conv1": b.conv1, "backbone_blocks": b.blocks,
                "neck": self.model.neck, "head": self.model.head}


# In the 4-level neck, top_down_blocks.1 is the P4->P3 merge; with 2 levels it is top_down_blocks.0.
_REMAP_FROM_4_LEVEL = {"neck.top_down_blocks.0.": "neck.top_down_blocks.1."}


def _state(path):
    ckpt = torch.load(path, map_location="cpu", weights_only=False)
    return ckpt.get("model", ckpt) if isinstance(ckpt, dict) else ckpt


def _nc_of(sd, reg_max=7):
    return sd["head.gfl_cls.0.weight"].shape[0] - 4 * (reg_max + 1)


def warm_start(model, path):
    """Copies every same-shape tensor from a 4-level (or 2-level) PicoDet-ESNet checkpoint."""
    src = _state(path)
    four_level = any(k.startswith("backbone.blocks.10.") for k in src)
    own, take = model.model.state_dict(), {}
    for k, v in own.items():
        sk = k
        if four_level:
            for new, old in _REMAP_FROM_4_LEVEL.items():
                if k.startswith(new):
                    sk = old + k[len(new):]
        if sk in src and src[sk].shape == v.shape:
            take[k] = src[sk]
    model.model.load_state_dict(take, strict=False)
    for part in ("backbone", "neck", "head"):
        n_own = sum(1 for k in own if k.startswith(part + "."))
        n_got = sum(1 for k in take if k.startswith(part + "."))
        print(f"  warm start {part:<8s}: {n_got}/{n_own} tensors from {path}")
    return model


def load_small(path, size="s"):
    sd = _state(path)
    return PicoDetSmallStride(path, size=size, neck_ch=sd["neck.trans.0.conv.weight"].shape[0])


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--data", default=None)
    p.add_argument("--weights", default=None, help="warm start: your headslim best.pt, LibrePICODETs.pt, or a small-stride ckpt")
    p.add_argument("--neck", type=int, default=96, help="96 (0.74 GFLOPs) or 64 (0.56 GFLOPs)")
    p.add_argument("--act", default="leakyrelu", choices=sorted(ACTS))
    p.add_argument("--gate", default="sigmoid", choices=sorted(GATES))
    p.add_argument("--size", default="s", choices=["s", "m", "l"])
    p.add_argument("--imgsz", type=int, nargs=2, default=[320, 480], metavar=("H", "W"))
    p.add_argument("--device", default="")
    p.add_argument("--epochs", type=int, default=300)
    p.add_argument("--batch", type=int, default=64)
    p.add_argument("--lr0", type=float, default=0.1, help="for batch 64; smaller batch -> 0.1 x batch / 64")
    p.add_argument("--workers", type=int, default=8)
    p.add_argument("--profile-only", action="store_true", help="print GMACs/GFLOPs at --imgsz and exit")
    args = p.parse_args()

    set_activation(args.act, gate=args.gate)
    nc = _nc_of(_state(args.weights)) if args.weights else 1
    model = PicoDetSmallStride(size=args.size, nb_classes=nc, neck_ch=args.neck)

    if args.profile_only:
        from torchinfo import summary
        s = summary(model.model.eval(), input_size=(1, 3, *args.imgsz), verbose=0)
        print(f"strides {STRIDES}, neck {args.neck}, {args.imgsz[0]}x{args.imgsz[1]}: "
              f"{s.total_mult_adds / 1e9:.4f} GMACs, {2 * s.total_mult_adds / 1e9:.4f} GFLOPs, {s.total_params:,} params")
        return
    if not args.data:
        p.error("--data is required for training")
    if args.weights:
        warm_start(model, args.weights)
    else:
        print("WARNING: no --weights given, training from scratch (pass your headslim best.pt or LibrePICODETs.pt)")

    print(model.train(data=args.data, epochs=args.epochs, batch=args.batch, lr0=args.lr0, device=args.device,
                      workers=args.workers, imgsz=tuple(args.imgsz)))
    print(model.val(data=args.data, imgsz=tuple(args.imgsz)))


if __name__ == "__main__":
    main()
