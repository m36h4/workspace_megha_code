# Dataset Analyzer — Deep Recursive Dataset Audit Tool

A single reusable Python script (`dataset_analyzer.py`, ~1,165 lines) that recursively
audits an object-detection dataset — folder by folder, subfolder by subfolder, class by
class — and produces a full client-ready report bundle: Excel, CSVs, PNG charts, and an
HTML report.

## Install

```bash
pip install -r requirements.txt
```

`scikit-image` and `tqdm` are optional — the script degrades gracefully (built-in entropy
calc / plain progress printing) if they aren't installed, so it will still run on a bare
client machine. `opencv-python`, `numpy`, `pandas`, `Pillow`, `matplotlib`, `openpyxl` are
required.

## Run

```bash
python dataset_analyzer.py --root /path/to/Dataset --out ./analysis
```

Your dataset can look like:

```
Dataset/
├── basic_train_caseA/
│     basketball/  img001.jpg  img001.json  ...
│     rugby/       ...
│     soccer/      ...
│     volleyball/  ...
├── basic_eval_caseA/
├── cc0_train_caseB/     (YOLO .txt labels)
└── other_any_caseA/     (single COCO annotations.json)
```

Every **top-level folder** is scanned independently, and the script **auto-detects which
annotation format that folder uses**:

| Format | How it's detected |
|---|---|
| **COCO** | A `*.json` anywhere in the folder containing `images` / `annotations` / `categories` keys |
| **YOLO** | Per-image `*.txt` files (`class cx cy w h`, normalized); reads `classes.txt` / `obj.names` if present |
| **Generic JSON** | Per-image `*.json` files — flexibly parses `bbox: [x,y,w,h]`, `xmin/ymin/xmax/ymax`, `x1/y1/x2/y2`, LabelMe-style `points`, etc., and `class`/`label`/`category`/`name` for the class field |

No annotations found in a folder → it's still fully audited for image quality, resolution,
duplicates, and naming issues, with an "images without labels" flag on every image.

### Useful flags

```
--sample N          only process N images per top folder (fast preview run)
--hash-threshold N  hamming-distance cutoff for near-duplicate detection (default 5)
--no-plots          skip PNG chart generation
--no-html           skip the HTML report
--resume            continue a previous run from its checkpoint (see below)
--no-checkpoint     disable checkpointing (on by default)
```

## Crash resilience & resuming a long run

On a large client dataset (tens of thousands of images), a single unreadable or
oversized image used to be able to kill the entire multi-hour run. This is now handled
at two levels:

1. **Every image is processed inside a try/except.** A corrupt file, an OpenCV
   out-of-memory error, an unusual annotation shape — anything — is logged to
   `Read Errors` / `Invalid Annotations` and the scan moves on to the next image. It
   never brings down the whole process.
2. **Checkpointing.** Every 250 images (and after each top-level folder), progress is
   saved to `<out>/_checkpoint.pkl`. If something still stops the run outright (you hit
   Ctrl+C, the machine loses power, disk fills up), just re-run the **same command** with
   `--resume` added — it will skip every image already recorded and continue from where
   it left off, instead of starting over.

```bash
python dataset_analyzer.py --root D:\...\balldataset\match_train_caseA --out ./analysis --resume
```

The checkpoint file is deleted automatically once a run finishes cleanly.

Also fixed: very large images (e.g. >4000px on a side — scanned/stitched/raw photos)
are now downscaled internally just for the pixel/quality-metric computation, so they
don't blow up memory the way the original crash did; width/height/resolution in the
report still reflect the real, full-size image.

## What it computes

- **Structure**: images, labels, missing images/labels, corrupt images, invalid JSON
- **Per folder / subfolder / class**: image count, object count, avg objects/image, mean
  resolution, mean brightness/contrast/blur, % blurry, % over/under-exposed
- **Image properties**: resolution distribution, width/height, aspect ratio, orientation
  (landscape/portrait/square)
- **Pixel stats**: mean/std R,G,B, brightness, contrast, saturation, entropy
- **Annotation stats**: objects/image, bbox width/height/area/aspect ratio
- **BBox analysis**: relative size (% of image), size bucket (Tiny/Small/Medium/Large),
  center-point heatmap, edge-touching & truncated-box flags
- **Quality**: duplicate & near-duplicate images (custom dHash + pHash, no external
  dependency needed), blur bucket, exposure bucket
- **Class distribution**: images/class, objects/class, imbalance ratio vs. the largest class
- **File naming**: non-ASCII filenames, same-name collisions within/across folders,
  risky/unsupported extensions
- **Label validation**: negative coordinates, zero-size boxes, boxes exceeding image
  bounds, empty label files, malformed JSON
- **Cross-folder duplicate detection**
- **COCO-readiness checklist** (missing/invalid/empty labels, duplicate images, corrupt
  images — pass/review status per check)

## Output (`./analysis/`)

```
analysis/
    dataset_summary.xlsx       <- one workbook, every table on its own sheet
    dataset_summary.csv
    folder_statistics.csv
    image_statistics.csv       <- one row per image, every metric above
    bbox_statistics.csv        <- one row per bounding box
    duplicate_images.csv
    blurry_images.csv
    invalid_annotations.csv
    plots/
        resolution.png  bbox_area.png  bbox_scatter.png  object_count.png
        brightness.png  contrast.png   blur.png           saturation.png
        entropy.png     rgb_histogram.png  heatmap.png    class_distribution.png
        folder_comparison.png  size_buckets.png
    report.html                 <- open this in a browser to hand to the client
```

## Notes on scale

- Near-duplicate detection is exhaustive (pairwise hamming distance) up to ~6,000 unique
  image hashes per run; beyond that it still runs exact-duplicate detection but skips the
  full pairwise near-duplicate pass and prints a note. For a very large client dataset,
  run it once per top-level folder (`--root Dataset/basic_train_caseA`) to keep this
  bounded, or ask me to add LSH/bucketed hashing for larger scale.
- Everything runs single-process. If a folder has hundreds of thousands of images, expect
  a genuinely long run — multiprocessing over images is a natural extension point
  (`_process_one_image` is already isolated per-image) if you need it faster.
- The generic-JSON bbox parser is heuristic (auto-detects `xywh` vs `xyxy` vs normalized).
  If your actual client JSON has a format it doesn't handle, send me one sample label file
  and I'll wire in an exact reader in a couple of lines — the parsing layer is fully
  isolated (`parse_generic_json_label`) so nothing else in the script needs to change.

## Tested against

A synthetic 3-format dataset (generic-JSON with class subfolders, YOLO, and COCO) mixing
in: a missing label, a malformed JSON label, an exact-duplicate image, and a non-ASCII
filename — all were correctly detected end-to-end before this was handed to you.

## Your annotation format

Fitted directly against your real label schema:
```json
{
  "file_name": "NANSU1_20260807_101019_0000_00.jpg",
  "dimensions": [1264, 848],
  "data": {
    "ball": [ { "entire": { "rect": [294, 208, 410, 324] } } ]
  }
}
```
This is auto-detected as the `json_nested` format: the class name is the key under
`"data"` (here `"ball"`), and `rect` is read as `[x1, y1, x2, y2]` in absolute pixel
coordinates. (The earlier generic-JSON parser didn't recognize this nested shape at all,
which is why counts were coming out wrong/zero — now fixed.) If `dimensions` in the JSON
doesn't match the image's real size, that's flagged as a non-fatal
`declared_dimensions_mismatch` warning in `invalid_annotations.csv` — the boxes still
get processed normally either way.

## Object pixel size before/after a resize (e.g. to 320x320)

Every bounding box now reports its pixel size both in the original image and after a
**letterbox resize** — uniform scale-to-fit + centered padding to a square canvas, so
there's no cropping and no aspect-ratio distortion (the standard way YOLO-style
pipelines prepare images). This shows, before you train anything, whether small objects
(e.g. a distant ball) will shrink to just a handful of pixels once downsized.

```
--target-size N          square canvas size to preview resizing to (default: 320)
--tiny-px-threshold N     flag an object "tiny after resize" if width or height drops
                          below this many pixels post-resize (default: 4.0)
```

New columns on every row of `bbox_statistics.csv` / the **BBox Statistics** sheet
(`320` changes to match `--target-size`):
```
resized_320_width_px   resized_320_height_px   resized_320_area_px
resized_320_x1/y1/x2/y2   resized_320_rel_area_pct   resized_320_size_bucket
tiny_after_resize_320
```

New sheets/files:
- **Resize Impact 320px** sheet (`resize_impact_320px.csv`) — per-class average object
  size before vs. after resize, and % of objects that become "tiny" post-resize.
- **Resized Size Distribution** sheet — Tiny/Small/Medium/Large buckets recomputed
  against the resized canvas.
- `plots/resize_impact_<N>px.png` and `plots/size_buckets_after_resize_<N>px.png`.
- The HTML report has an "Object Pixel Size: Original vs. After NxN Resize" section.

Example for a 640-based training pipeline instead of 320:
```bash
python dataset_analyzer.py --root /path/to/Dataset --out ./analysis --target-size 640
```
