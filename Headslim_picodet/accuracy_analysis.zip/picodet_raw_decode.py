"""Host-side decode for the 'raw' ONNX head style.

The raw ONNX has NO decode nodes. It returns one tensor per pyramid level, channels-first:
    out_s8  : (1, nc + 4*(reg_max+1), H/8,  W/8 )
    out_s16 : (1, nc + 4*(reg_max+1), H/16, W/16)
channels = [nc class logits | 4*(reg_max+1) box-distribution logits (l, t, r, b order)].

decode_levels() turns those into exactly what the stock export produced:
    (N, 4 + nc)  = [x1, y1, x2, y2 in canvas pixels | sigmoid class scores]
with anchors ordered level by level, row-major (y then x) -- same order as the stock graph.
This is the same math as PicoHead's export branch (softmax over reg_max+1 bins, expectation
x stride, distances from the cell centre at (i + 0.5) * stride).

Deployment note: this is cheap (a few thousand anchors) and runs on the host CPU.
"""
import numpy as np


def _softmax(x, axis=-1):
    x = x - x.max(axis=axis, keepdims=True)
    e = np.exp(x)
    return e / e.sum(axis=axis, keepdims=True)


def decode_levels(levels, strides, nc, reg_max=7):
    """levels: list of arrays (C, h, w) or (1, C, h, w), one per stride. Returns (N, 4+nc)."""
    outs = []
    proj = np.arange(reg_max + 1, dtype=np.float32)
    for lv, s in zip(levels, strides):
        lv = np.asarray(lv, dtype=np.float32)
        if lv.ndim == 4:
            lv = lv[0]
        c, h, w = lv.shape
        cls = lv[:nc]                                                  # (nc, h, w)
        box = lv[nc:nc + 4 * (reg_max + 1)].reshape(4, reg_max + 1, h, w)
        scores = 1.0 / (1.0 + np.exp(-cls))                            # sigmoid
        dist = (_softmax(box, axis=1) * proj[None, :, None, None]).sum(axis=1) * s   # (4, h, w)
        ys = (np.arange(h, dtype=np.float32) + 0.5) * s
        xs = (np.arange(w, dtype=np.float32) + 0.5) * s
        cx, cy = np.meshgrid(xs, ys)                                   # (h, w)
        boxes = np.stack([cx - dist[0], cy - dist[1], cx + dist[2], cy + dist[3]], axis=0)   # (4, h, w)
        merged = np.concatenate([boxes, scores], axis=0)               # (4+nc, h, w)
        outs.append(merged.reshape(4 + nc, h * w).T)                   # (h*w, 4+nc)
    return np.concatenate(outs, axis=0)
