"""Measures how YOUR images actually look (blur, noise, brightness, contrast, saturation) and
proposes corruption levels for accuracy_analysis.py from that data, so every level means
"a frame as bad as the worst X% of real frames" instead of a guessed number.

    python measure_conditions.py --data dataset_eval.yaml --split val --exposure 1/500 \
        --out conditions_20261124
    python accuracy_analysis.py ... --levels conditions_20261124/levels.json

All measurements are taken on the image region of the 320x480 letterboxed canvas -- the
pixels the model actually sees -- so they match how accuracy_analysis.py applies corruptions.

How each level is derived
  blur        sharpness = variance of the Laplacian. The sharpest 20% of images are blurred
              with increasing Gaussian sigma until their median sharpness equals the real
              10th / 5th percentile; a third level goes 1.5x beyond the 5th-percentile sigma.
  noise       per-image noise sigma (Immerkaer 1996). Added noise std = the amount that takes
              a typical (median) image to the noisiest 5% / 1%, plus one level 1.5x beyond.
  brightness  mean luminance; levels = 5th/25th/75th/95th percentile divided by the median.
  contrast    luminance std; same percentile ratios.
  saturation  mean HSV saturation; 5th and 95th percentile ratios, plus 0 (grayscale).
  hue         cannot be inferred from scene colours; kept at +-10 / +-20 deg (white-balance
              error range). Confirm with the camera team.
  motion blur physics, per sport: streak (px) = ball speed (m/s) x exposure (s) x pixels per
              metre, where pixels per metre = median ball size on the canvas (px) / real ball
              diameter (m). Speeds below are typical/fast values -- approximate, EDIT THEM for
              your footage. This is an upper bound: only motion across the image blurs.
"""
import argparse
import json
import os
from fractions import Fraction

import cv2
import numpy as np

from accuracy_analysis import DEFAULT_SPORTS, load_canvases, sport_of
from picodet_eval import load_ground_truth

# sport: (ball diameter m, typical speed m/s, fast speed m/s) -- approximate, edit for your data
BALL_PHYSICS = {
    "football": (0.22, 20, 35), "soccer": (0.22, 20, 35), "futsal": (0.20, 15, 25),
    "basketball": (0.24, 8, 15), "volleyball": (0.21, 15, 30), "handball": (0.19, 15, 25),
    "netball": (0.23, 8, 15), "rugby": (0.19, 15, 25), "water_polo": (0.22, 10, 20),
    "waterpolo": (0.22, 10, 20), "tennis": (0.067, 30, 60), "squash": (0.040, 30, 50),
    "tabletennis": (0.040, 10, 25), "table_tennis": (0.040, 10, 25), "pingpong": (0.040, 10, 25),
    "cricket": (0.072, 30, 45), "baseball": (0.074, 30, 45), "softball": (0.097, 20, 30),
    "hockey": (0.073, 20, 40), "golf": (0.043, 40, 75), "badminton": (0.065, 20, 80),
    "shuttle": (0.065, 20, 80), "dodgeball": (0.21, 10, 20), "kickball": (0.25, 10, 20),
}
LAP = np.array([[1, -2, 1], [-2, 4, -2], [1, -2, 1]], np.float32)


def stats(rgb):
    g = cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY).astype(np.float32)
    h, w = g.shape
    sharp = float(cv2.Laplacian(g, cv2.CV_32F).var())
    noise = float(np.sqrt(np.pi / 2) / (6 * (w - 2) * (h - 2)) * np.abs(cv2.filter2D(g, -1, LAP)[1:-1, 1:-1]).sum())
    sat = float(cv2.cvtColor(rgb, cv2.COLOR_RGB2HSV)[..., 1].astype(np.float32).mean())
    return dict(sharpness=sharp, noise=noise, brightness=float(g.mean()), contrast=float(g.std()), saturation=sat)


def lv(value, note):
    return {"value": round(float(value), 3), "note": note}


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--data", required=True)
    ap.add_argument("--split", default="val", help="split to measure (use train for more images)")
    ap.add_argument("--imgsz", type=int, nargs=2, default=[320, 480], metavar=("H", "W"))
    ap.add_argument("--exposure", default="1/500", help="camera exposure time in seconds, e.g. 1/500 (ask the camera team)")
    ap.add_argument("--group-by", default="name", choices=["name", "dir", "prefix", "none"])
    ap.add_argument("--sports", default=DEFAULT_SPORTS)
    ap.add_argument("--out", default="conditions")
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    exposure = float(Fraction(a.exposure))

    images, gts, _ = load_ground_truth(a.data, a.split)
    canv = load_canvases(images, tuple(a.imgsz))
    crops = {i: np.ascontiguousarray(c[:ch, :cw]) for i, (c, r, hw, (ch, cw)) in canv.items()}
    S = {k: np.array(v) for k, v in _columns([stats(im) for im in crops.values()]).items()}
    n = len(crops)
    print(f"measured {n} images ({a.split})")

    # ---- blur: calibrate Gaussian sigma on the sharpest 20% of images
    ids = list(crops)
    sharp_ids = [ids[k] for k in np.argsort(-S["sharpness"])[: max(3, n // 5)]]
    sigmas = np.round(np.arange(0.25, 6.01, 0.25), 2)
    curve = [np.median([cv2.Laplacian(cv2.cvtColor(cv2.GaussianBlur(crops[i], (0, 0), s), cv2.COLOR_RGB2GRAY)
                                      .astype(np.float32), cv2.CV_32F).var() for i in sharp_ids]) for s in sigmas]

    def sigma_for(target):
        for s, v in zip(sigmas, curve):
            if v <= target:
                return float(s)
        return float(sigmas[-1])
    p10, p5 = np.percentile(S["sharpness"], [10, 5])
    s10, s5 = sigma_for(p10), sigma_for(p5)
    blur = [lv(s10, "blurriest 10% real"), lv(s5, "blurriest 5% real"), lv(1.5 * s5, "1.5x beyond")]

    # ---- noise
    med, q95, q99 = np.percentile(S["noise"], [50, 95, 99])
    add = lambda t: max(2.0, float(np.sqrt(max(t ** 2 - med ** 2, 0))))
    noise = [lv(add(q95), "noisiest 5% real"), lv(add(q99), "noisiest 1% real"), lv(1.5 * add(q99), "1.5x beyond")]

    # ---- brightness / contrast / saturation as ratios to the median image
    def ratios(x, qs, notes):
        m = np.median(x)
        return [lv(np.percentile(x, q) / m, nt) for q, nt in zip(qs, notes)]
    def beyond(levels, lo_f=0.75, hi_f=1.25):
        """one level past the real range on each side, at least 25% away from the median image"""
        lo, hi = levels[0]["value"], levels[-1]["value"]
        return ([lv(min(lo * lo_f, lo_f), "beyond darkest/lowest real")] + levels
                + [lv(max(hi * hi_f, hi_f), "beyond brightest/highest real")])
    bright = beyond(ratios(S["brightness"], [5, 25, 75, 95],
                           ["darkest 5% real", "darker 25%", "brighter 25%", "brightest 5% real"]))
    contrast = beyond(ratios(S["contrast"], [5, 95], ["lowest 5% real", "highest 5% real"]))
    sat = [lv(0.0, "grayscale")] + beyond(ratios(S["saturation"], [5, 95], ["least saturated 5%", "most saturated 5%"]))
    hue = [lv(d, "white-balance error (default)") for d in (-20, -10, 10, 20)]

    # ---- motion blur physics per sport
    import contextlib, io
    from pycocotools.coco import COCO
    from libreyolo.data import load_data_config
    with contextlib.redirect_stdout(io.StringIO()):
        coco = COCO(load_data_config(a.data)[f"{a.split}_annotation_file"])
    sport = sport_of(images, {i: coco.loadImgs(i)[0]["file_name"] for i in images}, a.group_by, None, a.sports)
    rows, typ, fast = [], [], []
    for sp in sorted(set(sport.values())):
        sizes = np.concatenate([np.sqrt((g[:, 2] - g[:, 0]) * (g[:, 3] - g[:, 1])) * canv[i][1]
                                for i, g in gts.items() if sport[i] == sp and len(g)] or [np.zeros(0)])
        if sp not in BALL_PHYSICS or not len(sizes):
            rows.append([sp, len(sizes), "-", "-", "-", "-", "not in BALL_PHYSICS" if sp not in BALL_PHYSICS else "no balls"])
            continue
        d, v_t, v_f = BALL_PHYSICS[sp]
        ppm = np.median(sizes) / d
        b_t, b_f = v_t * exposure * ppm, v_f * exposure * ppm
        typ.append(b_t); fast.append(b_f)
        rows.append([sp, len(sizes), f"{np.median(sizes):.1f}", f"{d}", f"{v_t}/{v_f}", f"{b_t:.1f} / {b_f:.1f}", ""])
    motion = []
    if typ:
        for val, note in ((np.median(typ), "typical speed, median sport"), (max(typ), "typical speed, worst sport"),
                          (max(fast), "fast ball, worst sport")):
            k = int(round(val))
            if k >= 2:
                motion.append(lv(k + (k % 2 == 0), note))   # odd kernel length
    if not motion:
        motion = [lv(5, "default (physics gave <2 px)"), lv(9, "default"), lv(15, "default")]

    blur, noise, bright, contrast, sat, motion = (_dedupe(x) for x in (blur, noise, bright, contrast, sat, motion))
    levels = {"gaussian_blur": blur, "motion_blur": motion, "noise": noise, "brightness": bright,
              "contrast": contrast, "hue": hue, "saturation": sat,
              "_meta": {"split": a.split, "images": n, "exposure_s": exposure, "imgsz": a.imgsz}}
    with open(os.path.join(a.out, "levels.json"), "w") as f:
        json.dump(levels, f, indent=2)

    # ---- report
    q = lambda x: " / ".join(f"{np.percentile(x, p):.1f}" for p in (5, 25, 50, 75, 95))
    md = [f"# Image conditions ({a.split}, {n} images, measured on the {a.imgsz[0]}x{a.imgsz[1]} canvas)\n",
          "## Real-image statistics (percentiles 5 / 25 / 50 / 75 / 95)\n",
          "| Measure | Value |", "|---|---|",
          f"| Sharpness (Laplacian variance, higher = sharper) | {q(S['sharpness'])} |",
          f"| Noise sigma (0-255) | {q(S['noise'])} |",
          f"| Brightness (mean, 0-255) | {q(S['brightness'])} |",
          f"| Contrast (std, 0-255) | {q(S['contrast'])} |",
          f"| Saturation (mean, 0-255) | {q(S['saturation'])} |",
          "\n## Proposed corruption levels (levels.json)\n", "| Corruption | Level | Meaning |", "|---|---|---|"]
    names = {"gaussian_blur": "Gaussian blur sigma (px)", "motion_blur": "Motion blur length (px)",
             "noise": "Added noise std", "brightness": "Brightness (x)", "contrast": "Contrast (x)",
             "hue": "Hue shift (deg)", "saturation": "Saturation (x)"}
    for k, title in names.items():
        md += [f"| {title} | {x['value']} | {x['note']} |" for x in levels[k]]
    md += [f"\n## Motion blur from ball physics (exposure {a.exposure} s)\n",
           "streak (px) = speed x exposure x (ball px / ball diameter). Upper bound: only motion across the frame blurs. "
           "Speeds are approximate -- edit BALL_PHYSICS in measure_conditions.py.\n",
           "| Sport | Balls | Median ball size (px) | Diameter (m) | Speed typical/fast (m/s) | Streak typical / fast (px) | Note |",
           "|---|---|---|---|---|---|---|"] + ["| " + " | ".join(str(c) for c in r) + " |" for r in rows]
    md += ["\nSensitivity: the streak scales with exposure -- 1/250 s doubles it, 1/1000 s halves it."]
    with open(os.path.join(a.out, "conditions_report.md"), "w") as f:
        f.write("\n".join(md) + "\n")
    _hist(a.out, S)
    print("\n".join(md))
    print(f"\nwrote {a.out}/levels.json, conditions_report.md, conditions_hist.png")


def _dedupe(levels):
    """drop levels that round to the same value (keeps the first note); drop identity levels (1.0 / 0)"""
    seen, out = set(), []
    for x in levels:
        v = round(x["value"], 2)
        if v in seen:
            continue
        seen.add(v)
        out.append(x)
    return out


def _columns(rows):
    return {k: [r[k] for r in rows] for k in rows[0]}


def _hist(out, S):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    keys = ["sharpness", "noise", "brightness", "contrast", "saturation"]
    fig, axes = plt.subplots(1, 5, figsize=(16, 3))
    for ax, k in zip(axes, keys):
        ax.hist(S[k], bins=30, color="#4a78b5")
        for p, c in ((5, "#c0392b"), (50, "#333"), (95, "#c0392b")):
            ax.axvline(np.percentile(S[k], p), color=c, ls="--", lw=1)
        ax.set_title(k, fontsize=9); ax.tick_params(labelsize=7)
    fig.suptitle("Real-image conditions (dashed: 5th / median / 95th percentile)", fontsize=9)
    fig.tight_layout(); fig.savefig(os.path.join(out, "conditions_hist.png"), dpi=130); plt.close(fig)


if __name__ == "__main__":
    main()
