Accuracy analysis for Ohata-san (Exp-2.6 NanoDet-ResNet vs Exp-2.1.1 PicoDet)

Step 1 - measure your real images, get data-driven corruption levels
  python measure_conditions.py --data dataset_eval.yaml --split val --exposure 1/500 --out conditions
    -> conditions/levels.json, conditions_report.md, conditions_hist.png
    --exposure: camera exposure time (ask the Nikon team; 1/500 is a placeholder)
    --split train gives more images for the statistics
    Ball speeds/diameters for the motion-blur physics: BALL_PHYSICS in measure_conditions.py (edit)

Step 2 - run the analysis on both models
  python accuracy_analysis.py --data dataset_eval.yaml \
      --model "Exp-2.6=ONNX/nanodet_resnet_20261007.onnx:nanodetplus" \
      --model "Exp-2.1.1=ONNX/picodet_leakyrelu_2026_10_13.onnx:picodet" \
      --levels conditions/levels.json --breaking-point --out analysis
    -> analysis/summary.md (all tables), CSVs, charts (by_sport, by_ball_size, by_ball_position,
       by_balls_in_image, corruptions, breaking_point)
    PREPROC after ':' = the preset that reproduces each model's reported recall in picodet_eval_onnx.py
    Sport = ball name in the file name (--sports to add names; unmatched files are listed)
    --breaking-point adds ~10 min; --target-recall 0.70 by default

Needs in the same folder: picodet_eval.py, picodet_eval_onnx.py, picodet_letterbox.py, picodet_raw_decode.py
